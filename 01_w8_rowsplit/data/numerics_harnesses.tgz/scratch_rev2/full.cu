// Whole-kernel A/B.  Compiled twice (once against each header variant) into two binaries; each
// dumps every output tensor to a file and the two files are byte-compared.
#include "ops/linear/w8/w8_rowsplit_gemm_mma.cuh"

#include <cstdio>
#include <cstdlib>
#include <vector>

using namespace ninfer::ops::detail;

#define CK(x)                                                                                      \
    do {                                                                                           \
        cudaError_t e = (x);                                                                       \
        if (e != cudaSuccess) {                                                                    \
            printf("CUDA %s @%d\n", cudaGetErrorString(e), __LINE__);                              \
            exit(1);                                                                               \
        }                                                                                          \
    } while (0)

static unsigned st = 88172645u;
static unsigned rnd() {
    st ^= st << 13; st ^= st >> 17; st ^= st << 5; return st;
}
static int div_up(int a, int b) { return (a + b - 1) / b; }
static FILE* g_out = nullptr;
static const size_t PAD = 512;

template <class Sched, bool Full, W8Epilogue Ep>
void go(const char* tag, int m, int n, int k, int padded_k) {
    constexpr int BM = Sched::BM, BN = Sched::BN;
    constexpr bool kSwiGlu          = Ep == W8Epilogue::SwiGluSplitHalf;
    constexpr int kOutputRowsPerCta = kSwiGlu ? BM / 2 : BM;
    const int out_rows              = kSwiGlu ? m / 2 : m;
    const int kg                    = padded_k / 32;
    st                              = 12345u + (unsigned)(m * 31 + n * 7 + k);

    std::vector<std::uint16_t> hx((size_t)n * k + PAD);
    std::vector<std::uint8_t> hc((size_t)m * kg * 32 + PAD);
    std::vector<std::uint8_t> hs((size_t)m * kg * 2 + PAD);
    std::vector<std::uint16_t> ho((size_t)n * out_rows + PAD);
    for (auto& v : hx) { v = (std::uint16_t)((rnd() & 0x7f7fu) | 0x3000u); }
    for (auto& v : hc) { v = (std::uint8_t)(rnd() & 0xff); }
    for (size_t i = 0; i + 1 < hs.size(); i += 2) {
        std::uint16_t h = (std::uint16_t)(0x2000u + (rnd() % 0x1800u));
        if ((rnd() & 15) == 0) { h |= 0x8000u; }
        hs[i] = (std::uint8_t)(h & 0xff); hs[i + 1] = (std::uint8_t)(h >> 8);
    }
    for (auto& v : ho) { v = (std::uint16_t)(rnd() & 0x3fffu); }

    void *dx, *dc, *ds, *dout;
    CK(cudaMalloc(&dx, hx.size() * 2));
    CK(cudaMalloc(&dc, hc.size()));
    CK(cudaMalloc(&ds, hs.size()));
    CK(cudaMalloc(&dout, ho.size() * 2));
    CK(cudaMemcpy(dx, hx.data(), hx.size() * 2, cudaMemcpyHostToDevice));
    CK(cudaMemcpy(dc, hc.data(), hc.size(), cudaMemcpyHostToDevice));
    CK(cudaMemcpy(ds, hs.data(), hs.size(), cudaMemcpyHostToDevice));
    CK(cudaMemcpy(dout, ho.data(), ho.size() * 2, cudaMemcpyHostToDevice));

    const W8ContiguousOutput output{(__nv_bfloat16*)dout, out_rows};
    const dim3 grid(div_up(out_rows, kOutputRowsPerCta), div_up(n, BN), 1);
    w8_rowsplit_gemm_mma_kernel<Sched, Full, Ep, W8ContiguousOutput><<<grid, Sched::THREADS>>>(
        (const __nv_bfloat16*)dx, (const std::uint8_t*)dc, (const std::uint8_t*)ds, output, m, k, n,
        padded_k);
    cudaError_t e = cudaGetLastError();
    if (e == cudaSuccess) { e = cudaDeviceSynchronize(); }
    if (e != cudaSuccess) {
        printf("  %-16s LAUNCH/RUN ERROR %s\n", tag, cudaGetErrorString(e));
        fprintf(g_out, "%s ERROR\n", tag);
    } else {
        CK(cudaMemcpy(ho.data(), dout, ho.size() * 2, cudaMemcpyDeviceToHost));
        fprintf(g_out, "%s m=%d n=%d k=%d pk=%d\n", tag, m, n, k, padded_k);
        fwrite(ho.data(), 2, (size_t)n * out_rows, g_out);
        printf("  %-16s ok\n", tag);
    }
    cudaFree(dx); cudaFree(dc); cudaFree(ds); cudaFree(dout);
}

using A = W8RowSplitMmaGemmSchedule<64, 64, 64, 16, 2>;            // BK=64, WARPS_M=1
using B = W8RowSplitMmaGemmSchedule<128, 64, 64, 16, 2>;           // BK=64, WARPS_M=2
using C = W8RowSplitMmaGemmSchedule<96, 96, 48, 16, 2>;            // BM=96, WARPS_M=2
using D = W8RowSplitMmaGemmSchedule<48, 112, 48, 16, 2>;           // BM=48, THREADS=224
using E = W8RowSplitMmaGemmSchedule<64, 48, 16, 24, 2, 2, 128, 1>; // BK=128, ACT_STAGES=1
using F = W8RowSplitMmaGemmSchedule<32, 128, 32, 16, 2>;           // BM=32

int main(int argc, char** argv) {
    g_out = fopen(argv[1], "wb");
    go<A, true, W8Epilogue::Store>("A.full.store", 256, 128, 256, 256);
    go<B, true, W8Epilogue::Store>("B.full.store", 256, 128, 256, 256);
    go<C, true, W8Epilogue::Store>("C.full.store", 192, 192, 256, 256);
    go<D, true, W8Epilogue::Store>("D.full.store", 96, 224, 256, 256);
    go<E, true, W8Epilogue::Store>("E.full.store", 128, 96, 256, 256);
    go<F, true, W8Epilogue::Store>("F.full.store", 64, 256, 256, 256);
    go<A, true, W8Epilogue::Store>("A.full.k512", 128, 64, 512, 512);
    go<E, true, W8Epilogue::Store>("E.full.k512", 64, 48, 512, 512);
    go<C, true, W8Epilogue::Store>("C.full.k512", 96, 96, 512, 512);
    go<A, true, W8Epilogue::Residual>("A.full.resid", 256, 128, 256, 256);
    go<B, true, W8Epilogue::Residual>("B.full.resid", 256, 128, 256, 256);
    go<E, true, W8Epilogue::Residual>("E.full.resid", 128, 96, 256, 256);
    go<A, true, W8Epilogue::SwiGluSplitHalf>("A.full.swig", 256, 128, 256, 256);
    go<B, true, W8Epilogue::SwiGluSplitHalf>("B.full.swig", 256, 128, 256, 256);
    go<C, true, W8Epilogue::SwiGluSplitHalf>("C.full.swig", 192, 192, 256, 256);
    go<F, true, W8Epilogue::SwiGluSplitHalf>("F.full.swig", 128, 256, 256, 256);
    go<A, false, W8Epilogue::Store>("A.part.store", 200, 100, 224, 256);
    go<A, false, W8Epilogue::Store>("A.part.store2", 130, 70, 160, 256);
    go<A, false, W8Epilogue::Store>("A.part.k512", 100, 50, 480, 512);
    go<B, false, W8Epilogue::Store>("B.part.store", 300, 90, 96, 256);
    go<C, false, W8Epilogue::Store>("C.part.store", 100, 100, 32, 256);
    go<D, false, W8Epilogue::Store>("D.part.store", 50, 30, 64, 256);
    go<E, false, W8Epilogue::Store>("E.part.store", 70, 50, 128, 256);
    go<E, false, W8Epilogue::Store>("E.part.store2", 65, 49, 32, 256);
    go<E, false, W8Epilogue::Store>("E.part.k512", 71, 51, 392, 512);
    go<F, false, W8Epilogue::Store>("F.part.store", 33, 129, 96, 256);
    go<A, false, W8Epilogue::Residual>("A.part.resid", 200, 100, 224, 256);
    go<B, false, W8Epilogue::Residual>("B.part.resid", 296, 90, 96, 256);
    go<E, false, W8Epilogue::Residual>("E.part.resid", 72, 50, 128, 256);
    go<A, false, W8Epilogue::SwiGluSplitHalf>("A.part.swig", 200, 100, 224, 256);
    go<B, false, W8Epilogue::SwiGluSplitHalf>("B.part.swig", 268, 90, 96, 256);
    go<C, false, W8Epilogue::SwiGluSplitHalf>("C.part.swig", 132, 100, 32, 256);
    go<F, false, W8Epilogue::SwiGluSplitHalf>("F.part.swig", 100, 129, 96, 256);
    fclose(g_out);
    printf("wrote %s\n", argv[1]);
    return 0;
}
