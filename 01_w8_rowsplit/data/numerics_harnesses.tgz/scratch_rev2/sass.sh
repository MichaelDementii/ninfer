#!/bin/bash
set -e
cd /root/scratch_rev2
for v in base cand; do
  /usr/local/cuda-13.1/bin/nvcc -arch=sm_120a -std=c++20 -O3 -I /root/scratch_rev2/$v -I /root/ninfer_d4/src -cubin all_inst.cu -o $v.cubin
  /usr/local/cuda-13.1/bin/cuobjdump -sass $v.cubin > $v.sass
done
python3 - <<'PYEOF'
import re, collections
def split(path):
    txt=open(path).read()
    ks={}
    cur=None; buf=[]
    for line in txt.split("\n"):
        m=re.match(r"\s*Function : (\S+)", line)
        if m:
            if cur: ks[cur]="\n".join(buf)
            cur=m.group(1); buf=[]
        elif cur is not None:
            buf.append(line)
    if cur: ks[cur]="\n".join(buf)
    return ks
def counts(body):
    c=collections.Counter()
    for line in body.split("\n"):
        m=re.search(r"\*/\s+(@!?P\d+\s+)?([A-Z][A-Z0-9_.]*)", line)
        if m: c[m.group(2)]+=1
    return c
b=split("/root/scratch_rev2/base.sass"); ca=split("/root/scratch_rev2/cand.sass")
targets=[k for k in b if ("Li64ELi64ELi64ELi16ELi2ELi2ELi64ELi2EEELb1ELNS1_10W8EpilogueE0" in k) or ("Li64ELi48ELi16ELi24ELi2ELi2ELi128ELi1EEELb1ELNS1_10W8EpilogueE0" in k)]
for t in sorted(targets):
    cb=counts(b[t]); cc=counts(ca[t])
    keys=sorted(set(list(cb)+list(cc)))
    print("=== "+t)
    print("  total base=%d cand=%d"%(sum(cb.values()),sum(cc.values())))
    for k in keys:
        if k.startswith(("LDS","STS","SHFL","LDSM","I2F","F2F","HMMA","PRMT","LOP","SGXT","BAR","IMAD","ISETP","BSSY","BSYNC","LDGSTS","MUFU","FMUL","F2FP","CS2R")):
            if cb[k]!=cc[k]:
                print("   %-14s base=%-4d cand=%-4d  (%+d)"%(k,cb[k],cc[k],cc[k]-cb[k]))
PYEOF
