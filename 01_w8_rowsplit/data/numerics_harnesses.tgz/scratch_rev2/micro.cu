// Isolated dequant_w harness: baseline body vs candidate body, same inputs, compare As.
#include "ops/common/memory.cuh"

#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <vector>

using ninfer::ops::store_vec;

__device__ __forceinline__ int w8g32_swz64(int row, int col) {
    return (((col >> 3) ^ (row & 7)) << 3) | (col & 7);
}

union alignas(16) W8Bf16x8Bits {
    uint4 raw;
    __nv_bfloat162 pair[4];
};

// ---------------- baseline (origin/master) ----------------
template <int BM, int BK, int THREADS, int WARPS>
__global__ __launch_bounds__(THREADS) void k_base(const std::uint8_t* __restrict__ gCr,
                                                  const std::uint8_t* __restrict__ gSr,
                                                  __nv_bfloat16* __restrict__ gAs, int kt) {
    constexpr int SCALE_CACHE_BYTES = 16;
    __shared__ __align__(16) __nv_bfloat16 As[BM * BK];
    __shared__ __align__(16) std::uint8_t Cr[BM * BK];
    __shared__ __align__(16) std::uint8_t Sr[BM * SCALE_CACHE_BYTES];
    const int tid  = static_cast<int>(threadIdx.x);
    const int warp = tid >> 5;
    const int lane = tid & 31;
    for (int i = tid; i < BM * BK; i += THREADS) { Cr[i] = gCr[i]; }
    for (int i = tid; i < BM * SCALE_CACHE_BYTES; i += THREADS) { Sr[i] = gSr[i]; }
    for (int i = tid; i < BM * BK; i += THREADS) { As[i] = __ushort_as_bfloat16(0xdeadu); }
    __syncthreads();

    constexpr int GROUPS            = BK / 32;
    constexpr int SCALE_CACHE_TILES = 8 / GROUPS;
    const int scale_pair_offset     = (kt % SCALE_CACHE_TILES) * GROUPS * 2;
    const int half                  = lane >> 4;
    const int half_lane             = lane & 15;
    for (int row_pair = warp * 2; row_pair < BM; row_pair += WARPS * 2) {
        const int row = row_pair + half;
        unsigned scale_pair0;
        unsigned scale_pair1 = 0;
        if constexpr (GROUPS == 2) {
            scale_pair0 = half_lane == 0 ? *reinterpret_cast<const std::uint32_t*>(
                                               &Sr[row * SCALE_CACHE_BYTES + scale_pair_offset])
                                         : 0;
            scale_pair0 = __shfl_sync(0xffffffffu, scale_pair0, half * 16);
        } else {
            static_assert(GROUPS == 4);
            const unsigned lane_scale_pair =
                half_lane < 2 ? *reinterpret_cast<const std::uint32_t*>(
                                    &Sr[row * SCALE_CACHE_BYTES + scale_pair_offset + half_lane * 4])
                              : 0;
            scale_pair0 = __shfl_sync(0xffffffffu, lane_scale_pair, half * 16);
            scale_pair1 = __shfl_sync(0xffffffffu, lane_scale_pair, half * 16 + 1);
        }
#pragma unroll
        for (int gg = 0; gg < GROUPS; ++gg) {
            const unsigned scale_pair   = gg < 2 ? scale_pair0 : scale_pair1;
            const unsigned scale_bits   = (scale_pair >> ((gg & 1) * 16)) & 0xffffu;
            const float scale           = __half2float(__ushort_as_half(scale_bits));
            const int col               = gg * 32 + half_lane * 2;
            const std::uint16_t packed  = *reinterpret_cast<const std::uint16_t*>(&Cr[row * BK + col]);
            const int q0                = static_cast<int>(static_cast<std::int8_t>(packed & 0xffu));
            const int q1                = static_cast<int>(static_cast<std::int8_t>(packed >> 8));
            const __nv_bfloat162 values = __floats2bfloat162_rn(static_cast<float>(q0) * scale,
                                                                static_cast<float>(q1) * scale);
            store_vec(&As[row * BK + w8g32_swz64(row, col)], values);
        }
    }
    __syncthreads();
    for (int i = tid; i < BM * BK; i += THREADS) { gAs[i] = As[i]; }
}

// ---------------- candidate ----------------
template <int BM, int BK, int THREADS, int WARPS>
__global__ __launch_bounds__(THREADS) void k_cand(const std::uint8_t* __restrict__ gCr,
                                                  const std::uint8_t* __restrict__ gSr,
                                                  __nv_bfloat16* __restrict__ gAs, int kt) {
    constexpr int SCALE_CACHE_BYTES = 16;
    __shared__ __align__(16) __nv_bfloat16 As[BM * BK];
    __shared__ __align__(16) std::uint8_t Cr[BM * BK];
    __shared__ __align__(16) std::uint8_t Sr[BM * SCALE_CACHE_BYTES];
    const int tid = static_cast<int>(threadIdx.x);
    for (int i = tid; i < BM * BK; i += THREADS) { Cr[i] = gCr[i]; }
    for (int i = tid; i < BM * SCALE_CACHE_BYTES; i += THREADS) { Sr[i] = gSr[i]; }
    for (int i = tid; i < BM * BK; i += THREADS) { As[i] = __ushort_as_bfloat16(0xdeadu); }
    __syncthreads();

    constexpr int GROUPS            = BK / 32;
    constexpr int SCALE_CACHE_TILES = 8 / GROUPS;
    constexpr int kChunksPerRow     = BK / 8;
    static_assert(BK % 8 == 0, "a row of codes must tile into eight-code chunks");
    const int scale_pair_offset = (kt % SCALE_CACHE_TILES) * GROUPS * 2;
    for (int item = tid; item < BM * kChunksPerRow; item += THREADS) {
        const int row   = item / kChunksPerRow;
        const int chunk = item - row * kChunksPerRow;
        const int col   = chunk * 8;
        const int gg    = col >> 5;
        const float scale = __half2float(__ushort_as_half(*reinterpret_cast<const std::uint16_t*>(
            &Sr[row * SCALE_CACHE_BYTES + scale_pair_offset + gg * 2])));
        const uint2 packed = *reinterpret_cast<const uint2*>(&Cr[row * BK + col]);
        W8Bf16x8Bits decoded;
#pragma unroll
        for (int pair = 0; pair < 4; ++pair) {
            const unsigned word = (pair < 2 ? packed.x : packed.y) >> ((pair & 1) * 16);
            const int q0        = static_cast<int>(static_cast<std::int8_t>(word & 0xffu));
            const int q1        = static_cast<int>(static_cast<std::int8_t>((word >> 8) & 0xffu));
            decoded.pair[pair]  = __floats2bfloat162_rn(static_cast<float>(q0) * scale,
                                                        static_cast<float>(q1) * scale);
        }
        store_vec(&As[row * BK + w8g32_swz64(row, col)], decoded.raw);
    }
    __syncthreads();
    for (int i = tid; i < BM * BK; i += THREADS) { gAs[i] = As[i]; }
}

#define CK(x)                                                                                      \
    do {                                                                                           \
        cudaError_t e = (x);                                                                       \
        if (e != cudaSuccess) {                                                                    \
            printf("CUDA %s @%d\n", cudaGetErrorString(e), __LINE__);                              \
            exit(1);                                                                               \
        }                                                                                          \
    } while (0)

static unsigned rng_state = 123456789u;
static unsigned rnd() {
    rng_state ^= rng_state << 13;
    rng_state ^= rng_state >> 17;
    rng_state ^= rng_state << 5;
    return rng_state;
}

template <int BM, int BK, int THREADS, int WARPS>
void run(const char* tag, int reps) {
    constexpr int SCB              = 16;
    constexpr int GROUPS           = BK / 32;
    constexpr int SCALE_CACHE_TILES = 8 / GROUPS;
    std::vector<std::uint8_t> hCr(BM * BK), hSr(BM * SCB);
    std::uint8_t *dCr, *dSr;
    __nv_bfloat16 *dA0, *dA1;
    CK(cudaMalloc(&dCr, hCr.size()));
    CK(cudaMalloc(&dSr, hSr.size()));
    CK(cudaMalloc(&dA0, BM * BK * 2));
    CK(cudaMalloc(&dA1, BM * BK * 2));
    std::vector<std::uint16_t> a0(BM * BK), a1(BM * BK);
    // adversarial half-precision scale bit patterns
    const std::uint16_t nasty[] = {0x0000, 0x8000, 0x0001, 0x8001, 0x03ff, 0x0400, 0x3c00,
                                   0xbc00, 0x7bff, 0x7c00, 0xfc00, 0x7e00, 0xfe00, 0x7dff};
    int bad = 0;
    for (int r = 0; r < reps; ++r) {
        for (size_t i = 0; i < hCr.size(); ++i) { hCr[i] = static_cast<std::uint8_t>(rnd() & 0xff); }
        for (int row = 0; row < BM; ++row) {
            for (int b = 0; b < SCB; b += 2) {
                std::uint16_t v;
                if (r % 3 == 0) {
                    v = nasty[rnd() % (sizeof(nasty) / sizeof(nasty[0]))];
                } else {
                    v = static_cast<std::uint16_t>(rnd() & 0xffff);
                }
                hSr[row * SCB + b]     = static_cast<std::uint8_t>(v & 0xff);
                hSr[row * SCB + b + 1] = static_cast<std::uint8_t>(v >> 8);
            }
        }
        CK(cudaMemcpy(dCr, hCr.data(), hCr.size(), cudaMemcpyHostToDevice));
        CK(cudaMemcpy(dSr, hSr.data(), hSr.size(), cudaMemcpyHostToDevice));
        for (int kt = 0; kt < SCALE_CACHE_TILES * 2 + 1; ++kt) {
            k_base<BM, BK, THREADS, WARPS><<<1, THREADS>>>(dCr, dSr, dA0, kt);
            k_cand<BM, BK, THREADS, WARPS><<<1, THREADS>>>(dCr, dSr, dA1, kt);
            CK(cudaDeviceSynchronize());
            CK(cudaMemcpy(a0.data(), dA0, BM * BK * 2, cudaMemcpyDeviceToHost));
            CK(cudaMemcpy(a1.data(), dA1, BM * BK * 2, cudaMemcpyDeviceToHost));
            for (int i = 0; i < BM * BK; ++i) {
                if (a0[i] != a1[i]) {
                    if (bad < 5) {
                        printf("  MISMATCH %s rep=%d kt=%d idx=%d base=%04x cand=%04x\n", tag, r, kt,
                               i, a0[i], a1[i]);
                    }
                    ++bad;
                }
                if (a0[i] == 0xdead && a1[i] == 0xdead) {
                    if (bad < 5) { printf("  UNWRITTEN %s idx=%d\n", tag, i); }
                    ++bad;
                }
            }
        }
    }
    printf("%-28s BM=%3d BK=%3d THREADS=%4d  mismatches=%d\n", tag, BM, BK, THREADS, bad);
    cudaFree(dCr); cudaFree(dSr); cudaFree(dA0); cudaFree(dA1);
}

int main() {
    // BK=64 schedules (WARPS = BM/WM * BN/WN)
    run<32, 64, 64, 2>("R32 BN32", 6);
    run<32, 64, 96, 3>("R32 BN48", 6);
    run<32, 64, 128, 4>("R32 BN64", 6);
    run<32, 64, 160, 5>("R32 BN80", 6);
    run<32, 64, 192, 6>("R32 BN96", 6);
    run<32, 64, 224, 7>("R32 BN112", 6);
    run<32, 64, 256, 8>("R32 BN128", 6);
    run<48, 64, 128, 4>("R48 BN64", 6);
    run<48, 64, 160, 5>("R48 BN80", 6);
    run<48, 64, 192, 6>("R48 BN96", 6);
    run<48, 64, 224, 7>("R48 BN112", 6);
    run<48, 64, 256, 8>("R48 BN128", 6);
    run<64, 64, 64, 2>("R64 BN32", 6);
    run<64, 64, 96, 3>("R64 BN48", 6);
    run<64, 64, 128, 4>("R64 BN64", 6);
    run<64, 64, 160, 5>("R64 BN80", 6);
    run<64, 64, 192, 6>("R64 BN96", 6);
    run<64, 64, 224, 7>("R64 BN112", 6);
    run<64, 64, 256, 8>("R64 BN128", 6);
    run<96, 64, 256, 8>("R96 BN64", 6);
    run<96, 64, 320, 10>("R96 BN80", 6);
    run<96, 64, 384, 12>("R96 BN96", 6);
    run<96, 64, 448, 14>("R96 BN112", 6);
    run<128, 64, 256, 8>("R128 BN64", 6);
    run<128, 64, 320, 10>("R128 BN80", 6);
    // BK=128 schedule: <64,48,16,24,...,128,1> -> WARPS_M=4, WARPS_N=2, WARPS=8
    run<64, 128, 256, 8>("R64x16 BN48 K128", 8);
    printf("DONE\n");
    return 0;
}
