// Latency probe for the candidate's Sr (scale) read pattern vs a true broadcast and vs a
// deliberately N-way-conflicting pattern.  Counters are unavailable, so use clock64().
#include <cstdint>
#include <cstdio>

#define ITERS 4096

// pat 0: true broadcast   (every lane -> byte 0)
// pat 1: candidate BK=64  (row = tid/8, gg = (tid%8)/4 ; addr = row*16 + off + gg*2)
// pat 2: candidate BK=128 (row = tid/16, gg = (tid%16)/4 ; addr = row*16 + off + gg*2)
// pat 3: 4-way conflict   (addr = (tid%4)*128 + (tid/4)*2)  -> 4 distinct words per bank
// pat 4: 32-way conflict  (addr = tid*128)
template <int PAT>
__global__ void probe(std::uint16_t* out, long long* cyc, int off) {
    __shared__ __align__(16) std::uint8_t Sr[128 * 16];
    const int tid = threadIdx.x;
    for (int i = tid; i < 128 * 16; i += blockDim.x) { Sr[i] = (std::uint8_t)(i * 7 + 1); }
    __syncthreads();
    int addr;
    if constexpr (PAT == 0) {
        addr = 0;
    } else if constexpr (PAT == 1) {
        const int row = tid >> 3, gg = (tid & 7) >> 2;
        addr = row * 16 + off + gg * 2;
    } else if constexpr (PAT == 2) {
        const int row = tid >> 4, gg = (tid & 15) >> 2;
        addr = row * 16 + off + gg * 2;
    } else if constexpr (PAT == 3) {
        addr = (tid & 3) * 128 + (tid >> 2) * 2;
    } else {
        addr = (tid * 128) & 2047;
    }
    unsigned acc = 0;
    __syncthreads();
    long long t0 = clock64();
#pragma unroll 8
    for (int i = 0; i < ITERS; ++i) {
        acc += *reinterpret_cast<volatile std::uint16_t*>(&Sr[addr]);
        addr ^= (acc & 0);  // keep addr dependent-free but opaque
    }
    long long t1 = clock64();
    if (tid == 0) { *cyc = t1 - t0; }
    out[tid] = (std::uint16_t)acc;
}

int main() {
    std::uint16_t* d;
    long long* c;
    cudaMalloc(&d, 32 * 2);
    cudaMalloc(&c, 8);
    long long h;
    const char* names[] = {"broadcast (1 addr)", "cand BK=64  pattern", "cand BK=128 pattern",
                           "4-way conflict", "32-way conflict"};
    for (int rep = 0; rep < 3; ++rep) {
        printf("--- rep %d\n", rep);
        for (int p = 0; p < 5; ++p) {
            if (p == 0) probe<0><<<1, 32>>>(d, c, 0);
            if (p == 1) probe<1><<<1, 32>>>(d, c, 4);
            if (p == 2) probe<2><<<1, 32>>>(d, c, 8);
            if (p == 3) probe<3><<<1, 32>>>(d, c, 0);
            if (p == 4) probe<4><<<1, 32>>>(d, c, 0);
            cudaDeviceSynchronize();
            cudaMemcpy(&h, c, 8, cudaMemcpyDeviceToHost);
            printf("  %-22s %8.3f cycles / LDS.U16\n", names[p], (double)h / ITERS);
        }
    }
    return 0;
}
