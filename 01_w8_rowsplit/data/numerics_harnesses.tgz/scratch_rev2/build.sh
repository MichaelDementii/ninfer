#!/bin/bash
cd /root/scratch_rev2
python3 - <<'PYEOF'
p = "/root/scratch_rev2/all_inst.cu"
lines = open(p).read().split("\n")
inc = lines[0]
body = [l for l in lines[1:] if l.strip() and not l.startswith("using namespace") and l != "namespace ninfer::ops::detail {" and l != "}"]
out = [inc, "namespace ninfer::ops::detail {"] + body + ["}"]
open(p, "w").write("\n".join(out) + "\n")
PYEOF
head -4 all_inst.cu
for v in base cand; do
  /usr/local/cuda-13.1/bin/nvcc -arch=sm_120a -std=c++20 -O3 -I /root/scratch_rev2/$v -I /root/ninfer_d4/src -Xptxas -v -c all_inst.cu -o /dev/null 2> $v.ptxas.txt
  echo "$v exit=$?"
done
grep -c "Compiling entry function" base.ptxas.txt cand.ptxas.txt
head -8 base.ptxas.txt
