#!/bin/bash
set -e
cd /root/scratch_rev2
/usr/local/cuda-13.1/bin/nvcc -arch=sm_120a -std=c++20 -O3 -I /root/ninfer_d4/src -cubin micro.cu -o micro.cubin
/usr/local/cuda-13.1/bin/cuobjdump -sass micro.cubin > micro.sass
python3 - <<'PYEOF'
import re, collections
txt = open("/root/scratch_rev2/micro.sass").read()
ks = {}
cur = None; buf = []
for line in txt.split("\n"):
    m = re.match(r"\s*Function : (\S+)", line)
    if m:
        if cur: ks[cur] = buf
        cur = m.group(1); buf = []
    elif cur is not None:
        buf.append(line)
if cur: ks[cur] = buf
import subprocess
def demangle(n):
    return subprocess.run(["c++filt", n], capture_output=True, text=True).stdout.strip()
rows = []
for k, body in ks.items():
    c = collections.Counter()
    for line in body:
        m = re.search(r"\*/\s+(@!?P\d+\s+)?([A-Z][A-Z0-9_.]*)", line)
        if m: c[m.group(2)] += 1
    d = demangle(k)
    m = re.search(r"<(\d+), ?(\d+), ?(\d+), ?(\d+)>", d)
    if not m: continue
    BM, BK, TH, W = (int(x) for x in m.groups())
    kind = "base" if "k_base" in d else "cand"
    # scale loads = LDS (32-bit, base) / LDS.U16 (cand); code loads; stores
    rows.append((BM, BK, TH, kind, c))
seen = {}
for BM, BK, TH, kind, c in rows:
    seen.setdefault((BM, BK, TH), {})[kind] = c
print("%-18s | %-34s | %-34s" % ("BM/BK/THREADS", "baseline (per dequant_w call)", "candidate (per dequant_w call)"))
for key in sorted(seen):
    b = seen[key].get("base", collections.Counter()); ca = seen[key].get("cand", collections.Counter())
    def f(c):
        parts = []
        for m in ("LDS", "LDS.U16", "LDS.64", "STS", "STS.128", "SHFL.IDX"):
            if c[m]: parts.append("%s=%d" % (m, c[m]))
        return " ".join(parts)
    print("BM=%-3d BK=%-3d T=%-4d | %-34s | %-34s" % (key[0], key[1], key[2], f(b), f(ca)))
PYEOF
