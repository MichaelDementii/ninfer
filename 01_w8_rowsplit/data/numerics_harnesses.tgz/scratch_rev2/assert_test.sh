#!/bin/bash
# Does the new `BK % 8 == 0` assert catch the BK values the deleted `static_assert(GROUPS == 4)`
# used to catch?  Relax only the schedule-level BK gate and try BK = 40 (GROUPS == 1).
cd /root/scratch_rev2
rm -rf a40 && mkdir -p a40/base/ops/linear/w8 a40/cand/ops/linear/w8
for v in base cand; do
  sed 's|static_assert(BK == 64 \|\| BK == 128);|static_assert(BK % 8 == 0);|' \
      $v/ops/linear/w8/w8_rowsplit_gemm_mma.cuh > a40/$v/ops/linear/w8/w8_rowsplit_gemm_mma.cuh
  grep -n "static_assert(BK" a40/$v/ops/linear/w8/w8_rowsplit_gemm_mma.cuh
done
cat > a40/t.cu <<'EOF'
#include "ops/linear/w8/w8_rowsplit_gemm_mma.cuh"
namespace ninfer::ops::detail {
// BM=32 BN=32 WM=32 WN=16 MIN_BLOCKS=2 STAGES=2 BK=40 -> GROUPS = 40/32 = 1
using S = W8RowSplitMmaGemmSchedule<32,32,32,16,2,2,40>;
template __global__ void w8_rowsplit_gemm_mma_kernel<S,true,W8Epilogue::Store,W8ContiguousOutput>(
    const __nv_bfloat16*,const std::uint8_t*,const std::uint8_t*,W8ContiguousOutput,
    std::int32_t,std::int32_t,std::int32_t,std::int32_t);
}
EOF
for v in base cand; do
  echo "===== BK=40 with $v decode body ====="
  /usr/local/cuda-13.1/bin/nvcc -arch=sm_120a -std=c++20 -O3 -I /root/scratch_rev2/a40/$v \
      -I /root/ninfer_d4/src -c a40/t.cu -o /dev/null 2>&1 | grep -E "static assertion|error|static_assert" | head -6
  echo "  exit=${PIPESTATUS[0]}"
done
