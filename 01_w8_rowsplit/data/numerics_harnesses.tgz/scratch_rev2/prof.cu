// Dynamic shared-memory instruction / bank-conflict profile of dequant_w: baseline vs candidate.
// Each kernel stages once, then repeats the dequant body REPS times. A third "null" kernel does
// only the staging so the staging cost can be subtracted.
#include "ops/common/memory.cuh"

#include <cuda_bf16.h>
#include <cuda_fp16.h>
#include <cstdint>
#include <cstdio>

using ninfer::ops::store_vec;

__device__ __forceinline__ int w8g32_swz64(int row, int col) {
    return (((col >> 3) ^ (row & 7)) << 3) | (col & 7);
}
union alignas(16) W8Bf16x8Bits {
    uint4 raw;
    __nv_bfloat162 pair[4];
};

#define REPS 64

#define STAGE                                                                                      \
    constexpr int SCB = 16;                                                                        \
    __shared__ __align__(16) __nv_bfloat16 As[BM * BK];                                            \
    __shared__ __align__(16) std::uint8_t Cr[BM * BK];                                             \
    __shared__ __align__(16) std::uint8_t Sr[BM * SCB];                                            \
    const int tid = static_cast<int>(threadIdx.x);                                                 \
    for (int i = tid * 16; i < BM * BK; i += THREADS * 16) {                                       \
        store_vec(&Cr[i], *reinterpret_cast<const uint4*>(&gCr[i]));                               \
    }                                                                                              \
    for (int i = tid * 16; i < BM * SCB; i += THREADS * 16) {                                      \
        store_vec(&Sr[i], *reinterpret_cast<const uint4*>(&gSr[i]));                               \
    }                                                                                              \
    __syncthreads();

template <int BM, int BK, int THREADS, int WARPS>
__global__ __launch_bounds__(THREADS) void k_null(const std::uint8_t* __restrict__ gCr,
                                                  const std::uint8_t* __restrict__ gSr,
                                                  __nv_bfloat16* __restrict__ gAs) {
    STAGE
    for (int rep = 0; rep < REPS; ++rep) { __syncthreads(); }
    if (tid == 0) { gAs[0] = As[0]; }
}

template <int BM, int BK, int THREADS, int WARPS>
__global__ __launch_bounds__(THREADS) void k_base(const std::uint8_t* __restrict__ gCr,
                                                  const std::uint8_t* __restrict__ gSr,
                                                  __nv_bfloat16* __restrict__ gAs) {
    STAGE
    const int warp = tid >> 5;
    const int lane = tid & 31;
    constexpr int GROUPS             = BK / 32;
    constexpr int SCALE_CACHE_TILES  = 8 / GROUPS;
    for (int rep = 0; rep < REPS; ++rep) {
        const int kt                = rep;
        const int scale_pair_offset = (kt % SCALE_CACHE_TILES) * GROUPS * 2;
        const int half              = lane >> 4;
        const int half_lane         = lane & 15;
        for (int row_pair = warp * 2; row_pair < BM; row_pair += WARPS * 2) {
            const int row = row_pair + half;
            unsigned scale_pair0;
            unsigned scale_pair1 = 0;
            if constexpr (GROUPS == 2) {
                scale_pair0 = half_lane == 0 ? *reinterpret_cast<const std::uint32_t*>(
                                                   &Sr[row * SCB + scale_pair_offset])
                                             : 0;
                scale_pair0 = __shfl_sync(0xffffffffu, scale_pair0, half * 16);
            } else {
                static_assert(GROUPS == 4);
                const unsigned lane_scale_pair =
                    half_lane < 2 ? *reinterpret_cast<const std::uint32_t*>(
                                        &Sr[row * SCB + scale_pair_offset + half_lane * 4])
                                  : 0;
                scale_pair0 = __shfl_sync(0xffffffffu, lane_scale_pair, half * 16);
                scale_pair1 = __shfl_sync(0xffffffffu, lane_scale_pair, half * 16 + 1);
            }
#pragma unroll
            for (int gg = 0; gg < GROUPS; ++gg) {
                const unsigned scale_pair  = gg < 2 ? scale_pair0 : scale_pair1;
                const unsigned scale_bits  = (scale_pair >> ((gg & 1) * 16)) & 0xffffu;
                const float scale          = __half2float(__ushort_as_half(scale_bits));
                const int col              = gg * 32 + half_lane * 2;
                const std::uint16_t packed = *reinterpret_cast<const std::uint16_t*>(&Cr[row * BK + col]);
                const int q0 = static_cast<int>(static_cast<std::int8_t>(packed & 0xffu));
                const int q1 = static_cast<int>(static_cast<std::int8_t>(packed >> 8));
                const __nv_bfloat162 values = __floats2bfloat162_rn(static_cast<float>(q0) * scale,
                                                                    static_cast<float>(q1) * scale);
                store_vec(&As[row * BK + w8g32_swz64(row, col)], values);
            }
        }
        __syncthreads();
    }
    if (tid == 0) { gAs[0] = As[0]; }
}

template <int BM, int BK, int THREADS, int WARPS>
__global__ __launch_bounds__(THREADS) void k_cand(const std::uint8_t* __restrict__ gCr,
                                                  const std::uint8_t* __restrict__ gSr,
                                                  __nv_bfloat16* __restrict__ gAs) {
    STAGE
    constexpr int GROUPS            = BK / 32;
    constexpr int SCALE_CACHE_TILES = 8 / GROUPS;
    constexpr int kChunksPerRow     = BK / 8;
    for (int rep = 0; rep < REPS; ++rep) {
        const int kt                = rep;
        const int scale_pair_offset = (kt % SCALE_CACHE_TILES) * GROUPS * 2;
        for (int item = tid; item < BM * kChunksPerRow; item += THREADS) {
            const int row     = item / kChunksPerRow;
            const int chunk   = item - row * kChunksPerRow;
            const int col     = chunk * 8;
            const int gg      = col >> 5;
            const float scale = __half2float(__ushort_as_half(
                *reinterpret_cast<const std::uint16_t*>(&Sr[row * SCB + scale_pair_offset + gg * 2])));
            const uint2 packed = *reinterpret_cast<const uint2*>(&Cr[row * BK + col]);
            W8Bf16x8Bits decoded;
#pragma unroll
            for (int pair = 0; pair < 4; ++pair) {
                const unsigned word = (pair < 2 ? packed.x : packed.y) >> ((pair & 1) * 16);
                const int q0        = static_cast<int>(static_cast<std::int8_t>(word & 0xffu));
                const int q1        = static_cast<int>(static_cast<std::int8_t>((word >> 8) & 0xffu));
                decoded.pair[pair]  = __floats2bfloat162_rn(static_cast<float>(q0) * scale,
                                                            static_cast<float>(q1) * scale);
            }
            store_vec(&As[row * BK + w8g32_swz64(row, col)], decoded.raw);
        }
        __syncthreads();
    }
    if (tid == 0) { gAs[0] = As[0]; }
}

int main(int argc, char** argv) {
    std::uint8_t *dCr, *dSr;
    __nv_bfloat16* dA;
    cudaMalloc(&dCr, 128 * 128);
    cudaMalloc(&dSr, 128 * 16);
    cudaMalloc(&dA, 128 * 128 * 2);
    cudaMemset(dCr, 0x37, 128 * 128);
    cudaMemset(dSr, 0x3c, 128 * 16);
    const int sel = argc > 1 ? atoi(argv[1]) : 0;
    // 0/1/2 = BM64 BK64 T256 null/base/cand ; 3/4/5 = BM64 BK128 T256 ; 6/7/8 = BM128 BK64 T256
    if (sel == 0) k_null<64, 64, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    if (sel == 1) k_base<64, 64, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    if (sel == 2) k_cand<64, 64, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    if (sel == 3) k_null<64, 128, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    if (sel == 4) k_base<64, 128, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    if (sel == 5) k_cand<64, 128, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    if (sel == 6) k_null<128, 64, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    if (sel == 7) k_base<128, 64, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    if (sel == 8) k_cand<128, 64, 256, 8><<<1, 256>>>(dCr, dSr, dA);
    cudaDeviceSynchronize();
    printf("sel=%d err=%s\n", sel, cudaGetErrorString(cudaGetLastError()));
    return 0;
}
