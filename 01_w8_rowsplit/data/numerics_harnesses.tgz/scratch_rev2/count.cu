// Instrumented count of Sr (scale) loads per dequant_w call: warp-level instruction executions,
// active lanes, and distinct 32-bit shared words touched per warp.  Also checks warp convergence.
#include <cstdint>
#include <cstdio>

struct Ctr {
    unsigned long long warp_exec;      // warp-level executions of the scale load
    unsigned long long lane_active;    // sum of active lanes
    unsigned long long distinct_words; // sum over executions of distinct 32-bit words
    unsigned long long max_lanes_per_word;
    unsigned long long divergent;      // executions where activemask != 0xffffffff
};

__device__ __forceinline__ void tally(Ctr* c, int byte_addr) {
    const unsigned act  = __activemask();
    const int lane      = threadIdx.x & 31;
    const unsigned word = (unsigned)(byte_addr >> 2);
    const unsigned same = __match_any_sync(act, word);
    const bool leader   = (__ffs(same) - 1) == lane;
    const unsigned lead = __ballot_sync(act, leader);
    if (lane == (__ffs(act) - 1)) {
        atomicAdd(&c->warp_exec, 1ull);
        atomicAdd(&c->lane_active, (unsigned long long)__popc(act));
        atomicAdd(&c->distinct_words, (unsigned long long)__popc(lead));
        if (act != 0xffffffffu) { atomicAdd(&c->divergent, 1ull); }
    }
    // max lanes sharing one word
    if (leader) { atomicMax(&c->max_lanes_per_word, (unsigned long long)__popc(same)); }
}

template <int BM, int BK, int THREADS, int WARPS>
__global__ __launch_bounds__(THREADS) void k_base(Ctr* c, int kt) {
    constexpr int SCB = 16;
    __shared__ __align__(16) std::uint8_t Sr[BM * SCB];
    const int tid = threadIdx.x;
    for (int i = tid; i < BM * SCB; i += THREADS) { Sr[i] = (std::uint8_t)i; }
    __syncthreads();
    const int warp = tid >> 5, lane = tid & 31;
    constexpr int GROUPS            = BK / 32;
    constexpr int SCALE_CACHE_TILES = 8 / GROUPS;
    const int scale_pair_offset     = (kt % SCALE_CACHE_TILES) * GROUPS * 2;
    const int half                  = lane >> 4;
    const int half_lane             = lane & 15;
    unsigned sink                   = 0;
    for (int row_pair = warp * 2; row_pair < BM; row_pair += WARPS * 2) {
        const int row = row_pair + half;
        if constexpr (GROUPS == 2) {
            const int a = row * SCB + scale_pair_offset;
            tally(c, half_lane == 0 ? a : -4); // -4 => inactive lanes contribute a sentinel word
            sink += half_lane == 0 ? *reinterpret_cast<const std::uint32_t*>(&Sr[a]) : 0u;
        } else {
            const int a = row * SCB + scale_pair_offset + half_lane * 4;
            tally(c, half_lane < 2 ? a : -4);
            sink += half_lane < 2 ? *reinterpret_cast<const std::uint32_t*>(&Sr[a]) : 0u;
        }
    }
    if (sink == 0xdeadbeefu) { c->warp_exec += 1; }
}

template <int BM, int BK, int THREADS, int WARPS>
__global__ __launch_bounds__(THREADS) void k_cand(Ctr* c, int kt) {
    constexpr int SCB = 16;
    __shared__ __align__(16) std::uint8_t Sr[BM * SCB];
    const int tid = threadIdx.x;
    for (int i = tid; i < BM * SCB; i += THREADS) { Sr[i] = (std::uint8_t)i; }
    __syncthreads();
    constexpr int GROUPS            = BK / 32;
    constexpr int SCALE_CACHE_TILES = 8 / GROUPS;
    constexpr int kChunksPerRow     = BK / 8;
    const int scale_pair_offset     = (kt % SCALE_CACHE_TILES) * GROUPS * 2;
    unsigned sink                   = 0;
    for (int item = tid; item < BM * kChunksPerRow; item += THREADS) {
        const int row   = item / kChunksPerRow;
        const int chunk = item - row * kChunksPerRow;
        const int col   = chunk * 8;
        const int gg    = col >> 5;
        const int a     = row * SCB + scale_pair_offset + gg * 2;
        tally(c, a);
        sink += *reinterpret_cast<const std::uint16_t*>(&Sr[a]);
    }
    if (sink == 0xdeadbeefu) { c->warp_exec += 1; }
}

static Ctr run(void (*dummy)(), int) { Ctr z{}; return z; }

#define GO(K, BM, BK, TH, W, KT)                                                                   \
    do {                                                                                           \
        Ctr h{};                                                                                   \
        cudaMemcpy(d, &h, sizeof(Ctr), cudaMemcpyHostToDevice);                                    \
        K<BM, BK, TH, W><<<1, TH>>>(d, KT);                                                        \
        cudaDeviceSynchronize();                                                                   \
        cudaMemcpy(&h, d, sizeof(Ctr), cudaMemcpyDeviceToHost);                                    \
        printf("  %-6s BM=%-4d BK=%-4d T=%-4d | warp_exec=%-5llu lanes=%-6llu "                    \
               "distinct_words/exec=%.2f max_lanes/word=%llu divergent=%llu\n",                    \
               #K + 2, BM, BK, TH, h.warp_exec, h.lane_active,                                     \
               h.warp_exec ? (double)h.distinct_words / h.warp_exec : 0.0, h.max_lanes_per_word,   \
               h.divergent);                                                                       \
    } while (0)

int main() {
    Ctr* d;
    cudaMalloc(&d, sizeof(Ctr));
    printf("== scale (Sr) loads per single dequant_w call ==\n");
    printf("-- BK=64, kt=1 --\n");
    GO(k_base, 32, 64, 256, 8, 1);
    GO(k_cand, 32, 64, 256, 8, 1);
    GO(k_base, 64, 64, 256, 8, 1);
    GO(k_cand, 64, 64, 256, 8, 1);
    GO(k_base, 64, 64, 96, 3, 1);
    GO(k_cand, 64, 64, 96, 3, 1);
    GO(k_base, 96, 64, 448, 14, 1);
    GO(k_cand, 96, 64, 448, 14, 1);
    GO(k_base, 128, 64, 256, 8, 1);
    GO(k_cand, 128, 64, 256, 8, 1);
    GO(k_base, 48, 64, 224, 7, 3);
    GO(k_cand, 48, 64, 224, 7, 3);
    printf("-- BK=128, kt=1 --\n");
    GO(k_base, 64, 128, 256, 8, 1);
    GO(k_cand, 64, 128, 256, 8, 1);
    return 0;
}
